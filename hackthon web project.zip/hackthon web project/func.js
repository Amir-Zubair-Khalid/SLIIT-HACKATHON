
function Notes() {
 window.location.href = "/secondary pages/lecture notes/lecture.html"
}
function Time() {
 window.location.href = "/secondary pages/timetable/timetable.html"
}
function Guides() {
 window.location.href = "/secondary pages/guides/guides.html"
}
function Events() {
 window.location.href = "/secondary pages/events/events.html"
}
function Home() {
 window.location.href = "/index.html"
}